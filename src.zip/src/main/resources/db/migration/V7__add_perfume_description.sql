ALTER TABLE perfumes
    ADD COLUMN IF NOT EXISTS description TEXT;