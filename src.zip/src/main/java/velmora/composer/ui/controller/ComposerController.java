package velmora.composer.ui.controller;

import java.io.File;
import java.util.*;
import java.util.stream.Collectors;
import javafx.animation.*;
import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.collections.transformation.FilteredList;
import javafx.fxml.FXML;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.control.*;
import javafx.scene.input.*;
import javafx.scene.layout.*;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.chart.PieChart;
import javafx.scene.paint.Color;
import javafx.scene.shape.ArcType;
import javafx.scene.shape.Circle;
import javafx.scene.shape.StrokeLineCap;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.TextAlignment;
import javafx.scene.shape.Rectangle;
import javafx.stage.FileChooser;
import javafx.util.Duration;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;
import velmora.composer.model.Composition;
import velmora.composer.model.CompositionItem;
import velmora.composer.model.Note;
import velmora.composer.model.NoteType;
import velmora.composer.model.User;
import velmora.composer.repository.NoteRepository;
import velmora.composer.service.AutoSaveService;
import velmora.composer.service.CompositionService;
import velmora.composer.service.SynergyService;
import velmora.composer.service.analysis.AnalysisResult;
import velmora.composer.service.analysis.CompositionAnalysisService;
import velmora.composer.service.analysis.FragranceTimelineService;
import velmora.composer.service.export.PdfExportService;
import velmora.composer.state.CompositionState;
import velmora.composer.ui.UserSession;
import velmora.composer.ui.ViewManager;

@Component
@RequiredArgsConstructor
public class ComposerController {

  private final NoteRepository noteRepository;
  private final CompositionService compositionService;
  private final SynergyService synergyService;
  private final CompositionAnalysisService analysisService;
  private final FragranceTimelineService timelineService;
  private final PdfExportService pdfExportService;
  private final AutoSaveService autoSaveService;
  private final UserSession userSession;
  private final ViewManager viewManager;
  private final CompositionState compositionState;

  @FXML private ListView<Note> materialsList;
  @FXML private Label materialCount;
  @FXML private Label selectedCount;
  @FXML private Button filterAll;
  @FXML private Button filterTop;
  @FXML private Button filterHeart;
  @FXML private Button filterBase;

  @FXML private TextField formulaName;
  @FXML private Label formulaStatus;

  @FXML private TilePane topChips;
  @FXML private TilePane heartChips;
  @FXML private TilePane baseChips;
  @FXML private Label topCount;
  @FXML private Label heartCount;
  @FXML private Label baseCount;
  @FXML private Label topPct;
  @FXML private Label heartPct;
  @FXML private Label basePct;
  @FXML private VBox topZone;
  @FXML private VBox heartZone;
  @FXML private VBox baseZone;

  @FXML private Pane particleLayer;
  @FXML private Pane floatingGradients;
  @FXML private VBox insightsContainer;

  @FXML private Canvas harmonyCircle;
  @FXML private Rectangle balanceBar;
  @FXML private Rectangle longevityBar;
  @FXML private Rectangle projectionBar;
  @FXML private Rectangle complexityBar;
  @FXML private Label balanceScore;
  @FXML private Label longevityValue;
  @FXML private Label projectionLabel;
  @FXML private Label complexityLabel;

  @FXML private Label formulaTotalLabel;
  @FXML private Label validationLabel;
  @FXML private VBox concentrationRows;

  @FXML private Label dominantFamilyValue;
  @FXML private Label openingCharValue;
  @FXML private Label dryDownCharValue;

  @FXML private PieChart familyChart;

  @FXML private StackPane pyramidTopContainer;
  @FXML private StackPane pyramidHeartContainer;
  @FXML private StackPane pyramidBaseContainer;
  @FXML private Rectangle pyramidTop;
  @FXML private Rectangle pyramidHeart;
  @FXML private Rectangle pyramidBase;
  @FXML private Label pyramidTopPct;
  @FXML private Label pyramidHeartPct;
  @FXML private Label pyramidBasePct;

  @FXML private Label totalConcentration;
  @FXML private Label concentrationValidation;

  @FXML private Slider timelineSlider;
  @FXML private Label currentStageValue;
  @FXML private Label currentCharValue;
  @FXML private Label currentNotesValue;
  @FXML private Label currentIntensityValue;
  @FXML private VBox noteActivityContainer;
  @FXML private VBox heatMapContainer;
  @FXML private Label fragranceStory;

  private final ObservableList<Note> allNotes = FXCollections.observableArrayList();
  private final ObservableList<Note> currentTopNotes = FXCollections.observableArrayList();
  private final ObservableList<Note> currentHeartNotes = FXCollections.observableArrayList();
  private final ObservableList<Note> currentBaseNotes = FXCollections.observableArrayList();
  private final Map<Long, Integer> notePercentages = new HashMap<>();
  private final Set<Long> previousNoteIds = new HashSet<>();
  private FilteredList<Note> filteredNotes;
  @FXML private Button closeDraftBtn;
  private Button activeFilter;
  private Long editingCompositionId;
  private static final double PERF_BAR_MAX = 160.0;
  private double currentTimeHours = 0;
  private boolean timelineUpdating = false;
  private boolean concentrationUpdating = false;

  @FXML
  public void initialize() {
    viewManager.setBeforeCatalogNavigate(() -> {
      compositionState.setCurrentNoteIds(allNotes().stream().map(Note::getId).collect(Collectors.toList()));
      compositionState.setCurrentNoteNames(allNotes().stream().map(Note::getName).collect(Collectors.toList()));
    });
    viewManager.setBeforeVaultNavigate(() -> {
      compositionState.setCurrentNoteIds(allNotes().stream().map(Note::getId).collect(Collectors.toList()));
      compositionState.setCurrentNoteNames(allNotes().stream().map(Note::getName).collect(Collectors.toList()));
    });
    loadNotes();
    clearPyramid();
    restoreFromState();
    setupFilterButtons();
    setupMaterialClick();
    setupDragDrop();
    initParticles();
    initFloatingGradients();
    initTimeline();
    updateAll();
    Platform.runLater(this::updateAnalysis);

    autoSaveService.setListener(status -> {
      formulaStatus.setText(switch (status) {
        case SAVED -> "\u25CF Saved";
        case SAVING -> "\u25CF Saving...";
        case UNSAVED -> "\u25CF Unsaved Changes";
      });
      formulaStatus.getStyleClass().removeAll("status-badge", "status-badge-warn", "status-badge-saved", "status-badge-saving");
      formulaStatus.getStyleClass().add(switch (status) {
        case SAVED -> "status-badge-saved";
        case SAVING -> "status-badge-saving";
        case UNSAVED -> "status-badge-warn";
      });
    });

    formulaName.textProperty().addListener((obs, old, val) -> {
      autoSaveService.setCurrentName(val);
      autoSaveService.markDirty();
    });

    if (editingCompositionId != null) {
      autoSaveService.setCurrentComposition(editingCompositionId, formulaName.getText(), "");
    }
  }

  private void loadNotes() {
    allNotes.setAll(noteRepository.findAll());
    filteredNotes = new FilteredList<>(allNotes, p -> true);
    materialsList.setItems(filteredNotes);
    materialsList.setCellFactory(lv -> new MaterialCardCell());
    updateMaterialCount();
  }

  private void clearPyramid() {
    currentTopNotes.clear();
    currentHeartNotes.clear();
    currentBaseNotes.clear();
    notePercentages.clear();
    previousNoteIds.clear();
  }

  private void restoreFromState() {
    List<Long> ids = compositionState.getCurrentNoteIds();
    if (ids != null && !ids.isEmpty()) {
      for (Long id : ids) {
        noteRepository.findById(id).ifPresent(note -> {
          NoteType type = note.getType();
          if (type == null) return;
          List<Note> targetList = switch (type) {
            case TOP -> currentTopNotes;
            case HEART -> currentHeartNotes;
            case BASE -> currentBaseNotes;
          };
          if (!targetList.contains(note)) targetList.add(note);
        });
      }
      redistributePercentages();
    }
    if (compositionState.getFormulaName() != null) {
      formulaName.setText(compositionState.getFormulaName());
    }
    editingCompositionId = compositionState.getEditCompositionId();
    boolean isEditing = editingCompositionId != null;
    closeDraftBtn.setVisible(isEditing);
    closeDraftBtn.setManaged(isEditing);
    compositionState.clear();
  }

  private void setupFilterButtons() {
    activeFilter = filterAll;
    filterAll.setOnAction(e -> setFilter(null));
    filterTop.setOnAction(e -> setFilter(NoteType.TOP));
    filterHeart.setOnAction(e -> setFilter(NoteType.HEART));
    filterBase.setOnAction(e -> setFilter(NoteType.BASE));
    setFilter(null);
  }

  private void setFilter(NoteType type) {
    if (type == null) {
      filteredNotes.setPredicate(p -> true);
    } else {
      filteredNotes.setPredicate(n -> n.getType() == type);
    }
    for (var btn : new Button[]{filterAll, filterTop, filterHeart, filterBase}) {
      btn.getStyleClass().remove("active");
    }
    Button target = type == null ? filterAll
        : type == NoteType.TOP ? filterTop
        : type == NoteType.HEART ? filterHeart : filterBase;
    target.getStyleClass().add("active");
    activeFilter = target;
    updateMaterialCount();
  }

  private void setupMaterialClick() {
    materialsList.setOnMouseClicked(event -> {
      if (event.getButton() == MouseButton.PRIMARY && event.getClickCount() == 2) {
        Note selected = materialsList.getSelectionModel().getSelectedItem();
        if (selected != null) {
          addNoteToPyramid(selected);
        }
      }
    });
  }

  private void setupDragDrop() {
    materialsList.setCellFactory(lv -> {
      MaterialCardCell cell = new MaterialCardCell();
      cell.setOnDragDetected(event -> {
        Note note = cell.getItem();
        if (note == null) return;
        Dragboard db = cell.startDragAndDrop(TransferMode.COPY);
        ClipboardContent content = new ClipboardContent();
        content.putString(String.valueOf(note.getId()));
        db.setContent(content);
        cell.getStyleClass().add("dragging");
        event.consume();
      });
      cell.setOnDragDone(event -> {
        cell.getStyleClass().remove("dragging");
        event.consume();
      });
      return cell;
    });

    for (VBox zone : new VBox[]{topZone, heartZone, baseZone}) {
      zone.setOnDragOver(event -> {
        if (event.getGestureSource() != zone && event.getDragboard().hasString()) {
          event.acceptTransferModes(TransferMode.COPY);
          zone.getStyleClass().add("drag-over");
        }
        event.consume();
      });
      zone.setOnDragExited(event -> {
        zone.getStyleClass().remove("drag-over");
        event.consume();
      });
    }

    topZone.setOnDragDropped(event -> handleDrop(event, NoteType.TOP));
    heartZone.setOnDragDropped(event -> handleDrop(event, NoteType.HEART));
    baseZone.setOnDragDropped(event -> handleDrop(event, NoteType.BASE));
  }

  private void handleDrop(DragEvent event, NoteType type) {
    Dragboard db = event.getDragboard();
    if (db.hasString()) {
      long noteId = Long.parseLong(db.getString());
      noteRepository.findById(noteId).ifPresent(note -> {
        if (note.getType() == type) {
          addNoteToPyramid(note);
        }
      });
    }
    event.setDropCompleted(true);
    event.consume();
    ((VBox) event.getSource()).getStyleClass().remove("drag-over");
  }

  private void addNoteToPyramid(Note note) {
    NoteType type = note.getType();
    if (type == null) return;
    List<Note> targetList = switch (type) {
      case TOP -> currentTopNotes;
      case HEART -> currentHeartNotes;
      case BASE -> currentBaseNotes;
    };
    if (!targetList.contains(note)) {
      targetList.add(note);
      redistributePercentages();
      autoSaveService.markDirty();
    }
    updateAll();
  }

  private void removeNoteFromPyramid(Note note) {
    NoteType type = note.getType();
    if (type == null) return;
    List<Note> targetList = switch (type) {
      case TOP -> currentTopNotes;
      case HEART -> currentHeartNotes;
      case BASE -> currentBaseNotes;
    };
    targetList.remove(note);
    notePercentages.remove(note.getId());
    redistributePercentages();
    autoSaveService.markDirty();
    updateAll();
  }

  private void redistributePercentages() {
    List<Note> all = allNotes();
    notePercentages.clear();
    if (all.isEmpty()) return;

    boolean hasTop = !currentTopNotes.isEmpty();
    boolean hasHeart = !currentHeartNotes.isEmpty();
    boolean hasBase = !currentBaseNotes.isEmpty();

    double topTarget, heartTarget, baseTarget;
    if (hasTop && hasHeart && hasBase) {
      topTarget = 25; heartTarget = 40; baseTarget = 35;
    } else if (hasTop && hasHeart) {
      topTarget = 35; heartTarget = 65; baseTarget = 0;
    } else if (hasTop && hasBase) {
      topTarget = 40; baseTarget = 60; heartTarget = 0;
    } else if (hasHeart && hasBase) {
      heartTarget = 55; baseTarget = 45; topTarget = 0;
    } else {
      redistributeEvenly(all);
      return;
    }

    Map<NoteType, List<Note>> byType = new HashMap<>();
    for (NoteType t : new NoteType[]{NoteType.TOP, NoteType.HEART, NoteType.BASE}) {
      byType.put(t, new ArrayList<>());
    }
    for (Note n : all) {
      if (n.getType() != null) byType.get(n.getType()).add(n);
    }

    double[][] targets = {
        {NoteType.TOP.ordinal(), topTarget},
        {NoteType.HEART.ordinal(), heartTarget},
        {NoteType.BASE.ordinal(), baseTarget}
    };

    for (double[] t : targets) {
      NoteType type = NoteType.values()[(int) t[0]];
      double phasePct = t[1];
      List<Note> notes = byType.get(type);
      if (notes.isEmpty()) continue;
      int phaseTotal = (int) Math.round(phasePct);
      int perNote = phaseTotal / notes.size();
      int rem = phaseTotal - perNote * notes.size();
      for (int i = 0; i < notes.size(); i++) {
        notePercentages.put(notes.get(i).getId(), perNote + (i < rem ? 1 : 0));
      }
    }

    int missing = 100 - getTotalPercentage();
    if (missing != 0) {
      Note first = all.get(0);
      notePercentages.merge(first.getId(), missing, Integer::sum);
    }
  }

  private void redistributeEvenly(List<Note> all) {
    int total = all.size();
    int base = 100 / total;
    int remainder = 100 - base * total;
    for (int i = 0; i < all.size(); i++) {
      notePercentages.put(all.get(i).getId(), base + (i < remainder ? 1 : 0));
    }
  }

  @FXML
  private void handleAutoBalance() {
    redistributePercentages();
    updateAll();
  }

  private int getTotalPercentage() {
    return notePercentages.values().stream().mapToInt(Integer::intValue).sum();
  }

  private void updateAll() {
    renderChips();
    adjustZoneWidths();
    updateCounts();
    updateConcentrationDisplay();
    updatePhasePercentages();
    updateAnalysis();
  }

  private void renderChips() {
    renderChipPane(topChips, currentTopNotes);
    renderChipPane(heartChips, currentHeartNotes);
    renderChipPane(baseChips, currentBaseNotes);
  }

  private void adjustZoneWidths() {
    adjustZoneWidth(topZone, topChips);
    adjustZoneWidth(heartZone, heartChips);
    adjustZoneWidth(baseZone, baseChips);
  }

  private void adjustZoneWidth(VBox zone, TilePane chips) {
    int count = chips.getChildren().size();
    int cols = count == 0 ? 4 : Math.min(4 + (count - 1) / 4, 8);
    chips.setPrefColumns(cols);

    Region parent = (Region) zone.getParent();
    double parentWidth = parent.getWidth() > 0 ? parent.getWidth() : 700;
    double maxAllowed = parentWidth * 0.7;

    double zoneWidth;
    if (count == 0) {
      zoneWidth = Math.min(310, maxAllowed);
    } else {
      double chipWidth = 150;
      double hgap = 6;
      double zoneHpad = 40;
      zoneWidth = cols * chipWidth + (cols - 1) * hgap + zoneHpad;
      zoneWidth = Math.min(zoneWidth, maxAllowed);
      zoneWidth = Math.max(zoneWidth, 260);
    }
    zone.setPrefWidth(zoneWidth);
    zone.setMaxWidth(zoneWidth);
  }

  private void renderChipPane(TilePane pane, ObservableList<Note> notes) {
    Set<Long> currentIds = notes.stream().map(Note::getId).collect(Collectors.toSet());
    pane.getChildren().clear();
    for (Note note : notes) {
      boolean isNew = !previousNoteIds.contains(note.getId());
      pane.getChildren().add(createChip(note, isNew));
    }
    previousNoteIds.clear();
    previousNoteIds.addAll(currentIds);
    if (pane.getParent() instanceof VBox zone) {
      for (Node child : zone.getChildren()) {
        if (child instanceof Label label && label.getStyleClass().contains("zone-placeholder")) {
          label.setVisible(notes.isEmpty());
          label.setManaged(notes.isEmpty());
          break;
        }
      }
    }
  }

  private HBox createChip(Note note, boolean animate) {
    HBox chip = new HBox(4);
    chip.setAlignment(Pos.CENTER_LEFT);
    chip.getStyleClass().add("note-chip-glass");
    chip.getStyleClass().add(
        note.getType() == NoteType.TOP ? "chip-top"
        : note.getType() == NoteType.HEART ? "chip-heart"
        : "chip-base");

    if (animate) {
      chip.setScaleX(0.85);
      chip.setScaleY(0.85);
      chip.setOpacity(0);
      FadeTransition ft = new FadeTransition(Duration.millis(250), chip);
      ft.setToValue(1.0);
      ScaleTransition st = new ScaleTransition(Duration.millis(300), chip);
      st.setToX(1.0);
      st.setToY(1.0);
      st.setInterpolator(Interpolator.EASE_OUT);
      ft.play();
      st.play();
    }

    Label name = new Label(note.getName());
    name.setStyle("-fx-font-size: 16; -fx-font-weight: 500; -fx-text-fill: #4B4B4B;");

    Label close = new Label("✕");
    close.getStyleClass().add("chip-close");
    close.setOnMouseClicked(e -> removeNoteFromPyramid(note));

    chip.getChildren().addAll(name, close);
    return chip;
  }

  private void updateCounts() {
    int top = currentTopNotes.size();
    int heart = currentHeartNotes.size();
    int base = currentBaseNotes.size();
    int total = top + heart + base;
    topCount.setText(String.valueOf(top));
    heartCount.setText(String.valueOf(heart));
    baseCount.setText(String.valueOf(base));
    selectedCount.setText(String.valueOf(total));

    double topPctVal = total > 0 ? (double) top / total * 100 : 0;
    double heartPctVal = total > 0 ? (double) heart / total * 100 : 0;
    double basePctVal = total > 0 ? (double) base / total * 100 : 0;
    topPct.setText(String.format("%.0f%%", topPctVal));
    heartPct.setText(String.format("%.0f%%", heartPctVal));
    basePct.setText(String.format("%.0f%%", basePctVal));
  }

  private void updatePhasePercentages() {
    int totalInNotes = allNotes().size();
    if (totalInNotes == 0) return;
    double topSum = currentTopNotes.stream().mapToInt(n -> notePercentages.getOrDefault(n.getId(), 0)).sum();
    double heartSum = currentHeartNotes.stream().mapToInt(n -> notePercentages.getOrDefault(n.getId(), 0)).sum();
    double baseSum = currentBaseNotes.stream().mapToInt(n -> notePercentages.getOrDefault(n.getId(), 0)).sum();
    double grand = topSum + heartSum + baseSum;
    if (grand == 0) return;

    topPct.setText(String.format("%.0f%%", topSum));
    heartPct.setText(String.format("%.0f%%", heartSum));
    basePct.setText(String.format("%.0f%%", baseSum));
  }

  private void updateConcentrationDisplay() {
    int total = getTotalPercentage();
    totalConcentration.setText("Total: " + total + "%");
    if (total == 100) {
      concentrationValidation.setText("✓ Formula balanced");
      concentrationValidation.setStyle("-fx-text-fill: #5A9E8F; -fx-font-size: 14; -fx-font-weight: 600;");
    } else if (total < 100) {
      int remaining = 100 - total;
      concentrationValidation.setText("⚠ Incomplete. " + remaining + "% remaining.");
      concentrationValidation.setStyle("-fx-text-fill: #C8954A; -fx-font-size: 14; -fx-font-weight: 600;");
    } else {
      int excess = total - 100;
      concentrationValidation.setText("✗ Exceeds by " + excess + "%.");
      concentrationValidation.setStyle("-fx-text-fill: #D9534F; -fx-font-size: 14; -fx-font-weight: 600;");
    }
  }

  private void updateAnalysis() {
    List<Note> all = allNotes();
    boolean empty = all.isEmpty();

    if (empty) {
      formulaTotalLabel.setText("Current Formula: 0%");
      validationLabel.setText("");
      balanceScore.setText("—");
      longevityValue.setText("—");
      projectionLabel.setText("—");
      complexityLabel.setText("—");
      dominantFamilyValue.setText("—");
      openingCharValue.setText("—");
      dryDownCharValue.setText("—");
      setPerfBar(balanceBar, 0);
      setPerfBar(longevityBar, 0);
      setPerfBar(projectionBar, 0);
      setPerfBar(complexityBar, 0);
      drawBalanceCircle(0);
      concentrationRows.getChildren().clear();
      familyChart.setAnimated(false);
      familyChart.getData().clear();
      updatePyramid(0, 0, 0);
      insightsContainer.getChildren().clear();
      Label hint = new Label("Add notes to see live analysis");
      hint.setStyle("-fx-font-size: 17; -fx-font-style: italic; -fx-text-fill: #B0ADA8;");
      insightsContainer.getChildren().add(hint);
      updateTimeline();
      return;
    }

    renderConcentrationRows();

    AnalysisResult result = analysisService.analyze(currentTopNotes, currentHeartNotes, currentBaseNotes);

    int balance = calcBalanceScore();
    drawBalanceCircle(balance);
    balanceScore.setText(balance + "%");
    setPerfBar(balanceBar, balance);

    double avgInt = all.stream().filter(n -> n.getIntensity() != null).mapToInt(Note::getIntensity).average().orElse(5);
    int total = all.size();
    long families = all.stream().map(Note::getCategory).filter(Objects::nonNull).distinct().count();

    double topSum = currentTopNotes.stream().mapToInt(n -> notePercentages.getOrDefault(n.getId(), 0)).sum();
    double heartSum = currentHeartNotes.stream().mapToInt(n -> notePercentages.getOrDefault(n.getId(), 0)).sum();
    double baseSum = currentBaseNotes.stream().mapToInt(n -> notePercentages.getOrDefault(n.getId(), 0)).sum();
    double grand = topSum + heartSum + baseSum;
    double topR = grand > 0 ? topSum / grand : 0;
    double heartR = grand > 0 ? heartSum / grand : 0;
    double baseR = grand > 0 ? baseSum / grand : 0;

    double totalLongevity = baseR * avgInt * 2.0 + heartR * avgInt * 1.2;
    int projectionScore = Math.min((int) avgInt * 14, 100);
    int complexityScore = Math.min(30 + (int) families * 14 + total * 4, 100);

    String longevityText = totalLongevity >= 8 ? "8h+" : totalLongevity >= 5 ? String.format("%.1fh", totalLongevity) : totalLongevity >= 3 ? String.format("%.1fh", totalLongevity) : String.format("%.1fh", totalLongevity);
    longevityValue.setText(longevityText);
    setPerfBar(longevityBar, Math.min((int) (totalLongevity * 12), 100));

    String projectionText = avgInt >= 8 ? "Beast Mode" : avgInt >= 6 ? "Strong" : avgInt >= 4 ? "Moderate" : "Soft";
    projectionLabel.setText(projectionText);
    setPerfBar(projectionBar, projectionScore);

    String complexityText = complexityScore >= 85 ? "Masterpiece" : complexityScore >= 70 ? "Complex" : complexityScore >= 50 ? "Moderate" : complexityScore >= 30 ? "Simple" : "Very Simple";
    complexityLabel.setText(complexityText);
    setPerfBar(complexityBar, complexityScore);

    var synergyResult = all.size() >= 2 ? synergyService.calculate(all) : null;

    updateOlfactoryProfile(all);
    updateFamilyChart(all);
    updatePyramid(topR, heartR, baseR);
    renderInsights(result, synergyResult);
    updateTimeline();
  }

  private void renderConcentrationRows() {
    concentrationRows.getChildren().clear();
    List<Note> all = allNotes();
    if (all.isEmpty()) return;

    for (Note note : all) {
      HBox row = new HBox(6);
      row.setAlignment(Pos.CENTER_LEFT);
      row.setOpacity(0);
      row.setScaleX(0.96);
      row.setScaleY(0.96);

      Circle typeDot = new Circle(4);
      String phaseColor = note.getType() == NoteType.TOP ? "#D69478"
          : note.getType() == NoteType.HEART ? "#B18DB8" : "#6DA89E";
      typeDot.setStyle("-fx-fill: " + phaseColor + ";");

      Label name = new Label(note.getName());
      name.setStyle("-fx-font-size: 13; -fx-font-weight: 600; -fx-text-fill: #4B4B4B; -fx-min-width: 70; -fx-max-width: 90; -fx-wrap-text: true;");

      int pct = notePercentages.getOrDefault(note.getId(), 0);
      Label pctLbl = new Label(pct + "%");
      pctLbl.setStyle("-fx-font-size: 12; -fx-font-weight: 700; -fx-text-fill: #6B6560; -fx-min-width: 30; -fx-alignment: center-right;");

      Slider slider = new Slider(0, 100, pct);
      slider.setShowTickLabels(false);
      slider.setShowTickMarks(false);
      slider.setPrefWidth(80);
      slider.setStyle("-fx-padding: 0; -fx-font-size: 10;");
      slider.valueProperty().addListener((obs, old, val) -> {
        if (concentrationUpdating) return;
        int intVal = (int) Math.round(val.doubleValue());
        if (intVal != notePercentages.getOrDefault(note.getId(), 0)) {
          notePercentages.put(note.getId(), intVal);
          pctLbl.setText(intVal + "%");
          concentrationUpdating = true;
          updateConcentrationDisplay();
          updatePhasePercentages();
          updateAnalysis();
          concentrationUpdating = false;
          autoSaveService.markDirty();
        }
      });

      row.getChildren().addAll(typeDot, name, slider, pctLbl);
      concentrationRows.getChildren().add(row);

      FadeTransition ft = new FadeTransition(Duration.millis(200), row);
      ft.setToValue(1.0);
      ScaleTransition st = new ScaleTransition(Duration.millis(250), row);
      st.setToX(1.0);
      st.setToY(1.0);
      st.setInterpolator(Interpolator.EASE_OUT);
      ft.play();
      st.play();
    }

    int totalPct = getTotalPercentage();
    formulaTotalLabel.setText("Current Formula: " + totalPct + "%");
    if (totalPct == 100) {
      validationLabel.setText("Balanced Formula \u2713");
      validationLabel.setStyle("-fx-font-size: 13; -fx-font-weight: 600; -fx-text-fill: #5A9E8F;");
    } else if (totalPct < 100) {
      int need = 100 - totalPct;
      validationLabel.setText("Need " + need + "% more");
      validationLabel.setStyle("-fx-font-size: 13; -fx-font-weight: 600; -fx-text-fill: #C8954A;");
    } else {
      int excess = totalPct - 100;
      validationLabel.setText("Reduce by " + excess + "%");
      validationLabel.setStyle("-fx-font-size: 13; -fx-font-weight: 600; -fx-text-fill: #D9534F;");
    }
  }

  private void updateOlfactoryProfile(List<Note> all) {
    if (all.isEmpty()) {
      dominantFamilyValue.setText("—");
      openingCharValue.setText("—");
      dryDownCharValue.setText("—");
      return;
    }

    Map<String, Long> famCount = all.stream()
        .map(n -> n.getCategory() != null ? n.getCategory() : "Other")
        .collect(Collectors.groupingBy(c -> c, Collectors.counting()));
    String dominant = famCount.entrySet().stream()
        .max(Map.Entry.comparingByValue())
        .map(Map.Entry::getKey)
        .orElse("Balanced");
    dominantFamilyValue.setText(dominant);

    String opening = "Unknown Opening";
    if (!currentTopNotes.isEmpty()) {
      List<String> cats = currentTopNotes.stream()
          .map(n -> n.getCategory() != null ? n.getCategory().toLowerCase() : "")
          .filter(c -> !c.isEmpty()).distinct().collect(Collectors.toList());
      if (cats.contains("citrus")) opening = "Fresh Citrus";
      else if (cats.contains("green")) opening = "Green Aromatic";
      else if (cats.contains("aromatic")) opening = "Herbal Fresh";
      else if (cats.contains("fruity")) opening = "Sweet Fruity";
      else if (cats.contains("spicy")) opening = "Warm Spicy";
      else if (cats.contains("floral")) opening = "Floral Fresh";
      else opening = "Bright Opening";
    }
    openingCharValue.setText(opening);

    String drydown = "Unknown Dry Down";
    if (!currentBaseNotes.isEmpty()) {
      List<String> cats = currentBaseNotes.stream()
          .map(n -> n.getCategory() != null ? n.getCategory().toLowerCase() : "")
          .filter(c -> !c.isEmpty()).distinct().collect(Collectors.toList());
      if (cats.contains("woody") && cats.contains("amber")) drydown = "Woody Amber";
      else if (cats.contains("woody")) drydown = "Warm Woody";
      else if (cats.contains("earthy")) drydown = "Dark Resinous";
      else if (cats.contains("musk")) drydown = "Soft Musky";
      else if (cats.contains("gourmand")) drydown = "Sweet Gourmand";
      else if (cats.contains("amber")) drydown = "Warm Amber";
      else if (cats.contains("leather")) drydown = "Leather Tobacco";
      else drydown = "Gentle Dry Down";
    }
    dryDownCharValue.setText(drydown);
  }

  private void updateFamilyChart(List<Note> all) {
    familyChart.getData().clear();
    if (all.isEmpty()) return;

    Map<String, Long> famCount = all.stream()
        .map(n -> n.getCategory() != null ? n.getCategory() : "Other")
        .collect(Collectors.groupingBy(c -> c, Collectors.counting()));
    long total = all.size();

    Map<String, String> colorMap = new HashMap<>();
    colorMap.put("Citrus", "#D69478");
    colorMap.put("Floral", "#B18DB8");
    colorMap.put("Woody", "#6DA89E");
    colorMap.put("Earthy", "#8B9E6D");
    colorMap.put("Oriental", "#C8954A");
    colorMap.put("Spicy", "#D9534F");
    colorMap.put("Fresh", "#5A9E8F");
    colorMap.put("Aquatic", "#4A9EB8");
    colorMap.put("Leather", "#8B4513");
    colorMap.put("Gourmand", "#D4A89A");
    colorMap.put("Green", "#7D9E6D");
    colorMap.put("Aromatic", "#8DA89E");
    colorMap.put("Fruity", "#E2A998");

    for (var entry : famCount.entrySet()) {
      String name = entry.getKey();
      double pct = (double) entry.getValue() / total * 100;
      PieChart.Data slice = new PieChart.Data(name + " " + String.format("%.0f%%", pct), entry.getValue());
      familyChart.getData().add(slice);
    }

    familyChart.getData().forEach(d -> {
      String cat = d.getName().replaceAll("\\s+\\d+%", "");
      String color = colorMap.getOrDefault(cat, "#C4BFB9");
      d.getNode().setStyle("-fx-pie-color: " + color + ";");
    });
  }

  private void updatePyramid(double topR, double heartR, double baseR) {
    double maxW = 240;
    double topW = Math.max(40, maxW * Math.max(0.2, topR));
    double heartW = Math.max(60, maxW * Math.max(0.3, heartR));
    double baseW = Math.max(30, maxW * Math.max(0.15, baseR));

    animatePyramidBar(pyramidTop, topW);
    animatePyramidBar(pyramidHeart, heartW);
    animatePyramidBar(pyramidBase, baseW);

    pyramidTopPct.setText(String.format("%.0f%%", topR * 100));
    pyramidHeartPct.setText(String.format("%.0f%%", heartR * 100));
    pyramidBasePct.setText(String.format("%.0f%%", baseR * 100));
  }

  private void animatePyramidBar(Rectangle bar, double target) {
    if (bar.getWidth() == target) return;
    Timeline anim = new Timeline(
        new KeyFrame(Duration.millis(400),
            new KeyValue(bar.widthProperty(), target, Interpolator.EASE_OUT))
    );
    anim.play();
  }

  private int calcBalanceScore() {
    int total = currentTopNotes.size() + currentHeartNotes.size() + currentBaseNotes.size();
    if (total == 0) return 0;
    double topR = (double) currentTopNotes.size() / total;
    double heartR = (double) currentHeartNotes.size() / total;
    double baseR = (double) currentBaseNotes.size() / total;
    if (topR == 0 || heartR == 0 || baseR == 0) return 25;
    double score = 100;
    score -= Math.abs(topR - 0.30) * 50;
    score -= Math.abs(heartR - 0.50) * 40;
    score -= Math.abs(baseR - 0.20) * 50;
    return Math.max(0, Math.min(100, (int) score));
  }

  private void drawBalanceCircle(int value) {
    if (harmonyCircle == null) return;
    double w = harmonyCircle.getWidth();
    double h = harmonyCircle.getHeight();
    double cx = w / 2;
    double cy = h / 2;
    double r = Math.min(cx, cy) - 3;
    double angle = 360.0 * Math.min(100, Math.max(0, value)) / 100.0;

    GraphicsContext gc = harmonyCircle.getGraphicsContext2D();
    gc.clearRect(0, 0, w, h);

    gc.setLineWidth(2.5);
    gc.setStroke(Color.rgb(234, 230, 223));
    gc.strokeArc(cx - r, cy - r, r * 2, r * 2, 0, 360, ArcType.OPEN);

    Color fillColor = value >= 70 ? Color.rgb(177, 141, 184)
        : value >= 40 ? Color.rgb(200, 149, 74)
        : Color.rgb(217, 83, 79);
    gc.setStroke(fillColor);
    gc.setLineCap(StrokeLineCap.ROUND);
    gc.strokeArc(cx - r, cy - r, r * 2, r * 2, 90, -angle, ArcType.OPEN);
  }

  private void setPerfBar(Rectangle bar, int value) {
    double target = PERF_BAR_MAX * value / 100.0;
    if (bar.getWidth() == target) return;
    Timeline anim = new Timeline(
        new KeyFrame(Duration.millis(400),
            new KeyValue(bar.widthProperty(), target, Interpolator.EASE_OUT))
    );
    anim.play();
  }

  private void renderInsights(AnalysisResult result, SynergyService.SynergyResult synergy) {
    insightsContainer.getChildren().clear();
    List<Note> all = allNotes();
    if (all.isEmpty()) {
      Label hint = new Label("Add notes to see live analysis");
      hint.setStyle("-fx-font-size: 17; -fx-font-style: italic; -fx-text-fill: #B0ADA8;");
      insightsContainer.getChildren().add(hint);
      return;
    }

    double topSum = currentTopNotes.stream().mapToInt(n -> notePercentages.getOrDefault(n.getId(), 0)).sum();
    double heartSum = currentHeartNotes.stream().mapToInt(n -> notePercentages.getOrDefault(n.getId(), 0)).sum();
    double baseSum = currentBaseNotes.stream().mapToInt(n -> notePercentages.getOrDefault(n.getId(), 0)).sum();
    double grand = topSum + heartSum + baseSum;
    double topR = grand > 0 ? topSum / grand : 0;
    double heartR = grand > 0 ? heartSum / grand : 0;
    double baseR = grand > 0 ? baseSum / grand : 0;

    double avgInt = all.stream().filter(n -> n.getIntensity() != null).mapToInt(Note::getIntensity).average().orElse(5);
    long families = all.stream().map(Note::getCategory).filter(Objects::nonNull).distinct().count();
    long catsCount = families;
    int totalPct = getTotalPercentage();
    long citrusCount = countByCategory(all, "Citrus");
    long woodyCount = countByCategory(all, "Woody");
    long totalNotes = all.size();

    // --- Phase Analysis cards ---
    if (result.topInsight() != null && !result.topInsight().isBlank()) {
      addInsightCard("\u25B2 TOP NOTES", result.topInsight(),
          "rgba(214,148,120,0.12)", "#B5704A");
    }
    if (result.heartInsight() != null && !result.heartInsight().isBlank()) {
      addInsightCard("\u25C6 HEART NOTES", result.heartInsight(),
          "rgba(177,141,184,0.12)", "#6B67A8");
    }
    if (result.baseInsight() != null && !result.baseInsight().isBlank()) {
      addInsightCard("\u25BC BASE NOTES", result.baseInsight(),
          "rgba(109,168,158,0.12)", "#3D7070");
    }

    // --- Synergy note-pair insights ---
    if (synergy != null) {
      for (var ins : synergy.good()) {
        addInsightCard("\u2713 SYNERGY", ins.explanation(),
            "rgba(90,158,143,0.12)", "#5A9E8F");
      }
      for (var ins : synergy.conflicts()) {
        addInsightCard("\u26A0 CONFLICT", ins.explanation(),
            "rgba(217,83,79,0.12)", "#D9534F");
      }
      for (var w : synergy.warnings()) {
        addInsightCard("\u26A0 WARNING", w,
            "rgba(200,149,74,0.12)", "#C8954A");
      }
    }

    // --- Generated suggestions ---
    List<String> suggestions = new ArrayList<>();
    if (woodyCount == 0 && !currentBaseNotes.isEmpty())
      suggestions.add("Add woody notes for better longevity.");
    if (heartR < 0.3 && !currentHeartNotes.isEmpty())
      suggestions.add("Increase heart phase by 10-15% for better depth.");
    if (citrusCount > totalNotes * 0.4)
      suggestions.add("Reduce citrus concentration slightly.");
    if (avgInt < 4 && totalNotes > 1)
      suggestions.add("Consider higher intensity notes for better projection.");
    if (families < 3 && totalNotes >= 3)
      suggestions.add("Add notes from different families for more complexity.");
    if (totalPct != 100)
      suggestions.add("Balance the formula to 100% for optimal performance.");
    if (topR > 0.5)
      suggestions.add("Top notes dominate (" + String.format("%.0f%%", topR * 100) + "). Consider reducing.");
    if (baseR < 0.15 && !currentBaseNotes.isEmpty())
      suggestions.add("Base notes are low (" + String.format("%.0f%%", baseR * 100) + "). Longevity may suffer.");
    if (avgInt < 3 && totalNotes > 2)
      suggestions.add("Low average intensity. The scent may be faint.");

    for (String s : suggestions) {
      addInsightCard("\uD83D\uDCA1 SUGGESTION", s,
          "rgba(177,141,184,0.12)", "#6B67A8");
    }

    if (insightsContainer.getChildren().isEmpty()) {
      Label hint = new Label("Add at least 2 notes for detailed insights");
      hint.setStyle("-fx-font-size: 15; -fx-font-style: italic; -fx-text-fill: #B0ADA8;");
      insightsContainer.getChildren().add(hint);
    }
  }

  private void addInsightCard(String tagText, String body, String bgColor, String textColor) {
    VBox card = new VBox(3);
    card.getStyleClass().add("insight-glass-card");
    card.setOpacity(0);
    card.setTranslateY(10);
    Label tag = new Label(tagText);
    tag.setStyle("-fx-background-color: " + bgColor + "; -fx-background-radius: 10; -fx-padding: 2 10; -fx-font-size: 12; -fx-font-weight: 700; -fx-text-fill: " + textColor + "; -fx-letter-spacing: 1;");
    Label text = new Label(body);
    text.setStyle("-fx-font-size: 14; -fx-text-fill: #5F5B57; -fx-wrap-text: true;");
    card.getChildren().addAll(tag, text);
    insightsContainer.getChildren().add(card);
    FadeTransition ft = new FadeTransition(Duration.millis(300), card);
    ft.setToValue(1.0);
    TranslateTransition tt = new TranslateTransition(Duration.millis(300), card);
    tt.setToY(0);
    tt.setInterpolator(Interpolator.EASE_OUT);
    ft.play();
    tt.play();
  }

  private void initTimeline() {
    timelineSlider.valueProperty().addListener((obs, old, val) -> {
      if (timelineUpdating) return;
      currentTimeHours = val.doubleValue();
      updateTimeline();
    });
  }

  private void updateTimeline() {
    List<Note> all = allNotes();
    boolean empty = all.isEmpty();

    if (empty) {
      currentStageValue.setText("—");
      currentCharValue.setText("—");
      currentNotesValue.setText("—");
      currentIntensityValue.setText("—");
      noteActivityContainer.getChildren().clear();
      heatMapContainer.getChildren().clear();
      fragranceStory.setText("Add notes to generate a fragrance story.");
      return;
    }

    timelineUpdating = true;
    if (timelineSlider != null) {
      timelineSlider.setValue(currentTimeHours);
    }
    timelineUpdating = false;

    var data = timelineService.calculate(currentTopNotes, currentHeartNotes, currentBaseNotes,
        notePercentages, currentTimeHours);

    var phase = data.currentPhase();
    if (phase != null) {
      currentStageValue.setText(phase.name());
      currentCharValue.setText(phase.character());
      currentNotesValue.setText(String.join(", ", phase.dominantNotes()));
      currentIntensityValue.setText(phase.intensity());
    }

    renderNoteActivity(data);
    renderHeatMap(data, all);
    fragranceStory.setText(data.story());

    animateTimelineNodes();
  }

  private void renderNoteActivity(FragranceTimelineService.TimelineData data) {
    noteActivityContainer.getChildren().clear();
    var active = data.curves().stream().filter(c -> c.isActive()).collect(Collectors.toList());
    if (active.isEmpty()) {
      Label none = new Label("No active notes at this time");
      none.setStyle("-fx-font-size: 13; -fx-font-style: italic; -fx-text-fill: #B0ADA8;");
      noteActivityContainer.getChildren().add(none);
      return;
    }
    for (var curve : active) {
      HBox row = new HBox(6);
      row.setAlignment(Pos.CENTER_LEFT);
      row.getStyleClass().add("activity-note-row");
      Circle dot = new Circle(3);
      dot.setStyle("-fx-fill: " + curve.color() + ";");
      Label name = new Label(curve.noteName());
      name.getStyleClass().add("activity-label");
      Label pct = new Label(String.format("%.0f%%", curve.currentActivity() * 100));
      pct.setStyle("-fx-font-size: 12; -fx-font-weight: 600; -fx-text-fill: #B0ADA8; -fx-min-width: 32; -fx-alignment: center-right;");
      Region spacer = new Region();
      HBox.setHgrow(spacer, Priority.ALWAYS);
      row.getChildren().addAll(dot, name, spacer, pct);
      noteActivityContainer.getChildren().add(row);
    }
  }

  private void renderHeatMap(FragranceTimelineService.TimelineData data, List<Note> all) {
    heatMapContainer.getChildren().clear();
    if (data.curves().isEmpty()) {
      Label none = new Label("No notes to display");
      none.setStyle("-fx-font-size: 13; -fx-font-style: italic; -fx-text-fill: #B0ADA8;");
      heatMapContainer.getChildren().add(none);
      return;
    }
    double[] times = {0, 0.25, 0.5, 1, 2, 3, 4, 6, 8};
    for (var curve : data.curves()) {
      HBox row = new HBox(6);
      row.setAlignment(Pos.CENTER_LEFT);
      row.getStyleClass().add("heat-row");

      Label name = new Label(curve.noteName());
      name.getStyleClass().add("heat-label");

      HBox bars = new HBox(2);
      bars.setAlignment(Pos.CENTER_LEFT);
      HBox.setHgrow(bars, Priority.ALWAYS);

      for (int i = 0; i < times.length; i++) {
        double act = curve.activity()[i];
        StackPane seg = new StackPane();
        seg.setPrefWidth(16);
        seg.setPrefHeight(10);
        seg.setMaxWidth(16);
        seg.setMinWidth(8);
        String fill = act > 0.7 ? "rgba(177,141,184,0.7)"
            : act > 0.4 ? "rgba(177,141,184,0.4)"
            : act > 0.15 ? "rgba(177,141,184,0.2)"
            : "rgba(234,230,223,0.3)";
        seg.setStyle("-fx-background-color: " + fill + "; -fx-background-radius: 2;");
        bars.getChildren().add(seg);
      }

      row.getChildren().addAll(name, bars);
      heatMapContainer.getChildren().add(row);
    }
  }

  private void animateTimelineNodes() {
    for (Node node : new Node[]{currentStageValue, currentCharValue, currentNotesValue, currentIntensityValue, fragranceStory}) {
      if (node instanceof Label lbl) {
        FadeTransition ft = new FadeTransition(Duration.millis(200), lbl);
        ft.setFromValue(0.6);
        ft.setToValue(1.0);
        ft.play();
      }
    }
  }

  private long countByCategory(List<Note> notes, String category) {
    return notes.stream()
        .filter(n -> category.equalsIgnoreCase(n.getCategory()))
        .count();
  }

  private List<Note> allNotes() {
    List<Note> all = new ArrayList<>();
    all.addAll(currentTopNotes);
    all.addAll(currentHeartNotes);
    all.addAll(currentBaseNotes);
    return all;
  }

  private void updateMaterialCount() {
    materialCount.setText(filteredNotes.size() + " materials");
  }

  private void initParticles() {
    Random rand = new Random();
    List<Circle> particles = new ArrayList<>();
    String[] symbols = {"\u2726", "\u2022", "\u25E6", "\u2219"};
    for (int i = 0; i < 35; i++) {
      Circle c = new Circle(1 + rand.nextDouble() * 3);
      double t = rand.nextDouble();
      if (t < 0.33)      c.setFill(Color.rgb(214, 148, 120, 0.06 + rand.nextDouble() * 0.10));
      else if (t < 0.66) c.setFill(Color.rgb(177, 141, 184, 0.06 + rand.nextDouble() * 0.10));
      else                c.setFill(Color.rgb(109, 168, 158, 0.06 + rand.nextDouble() * 0.10));
      c.setCenterX(rand.nextDouble() * 600 + 20);
      c.setCenterY(rand.nextDouble() * 400 + 40);
      c.setOpacity(0);
      particleLayer.getChildren().add(c);
      particles.add(c);
    }

    Timeline tl = new Timeline();
    for (int i = 0; i < particles.size(); i++) {
      Circle p = particles.get(i);
      double delay = rand.nextDouble() * 15;
      double dur = 12 + rand.nextDouble() * 16;
      double dx = (rand.nextDouble() - 0.5) * 80;
      double dy = (rand.nextDouble() - 0.5) * 50;
      tl.getKeyFrames().addAll(
          new KeyFrame(Duration.seconds(delay), new KeyValue(p.opacityProperty(), 0)),
          new KeyFrame(Duration.seconds(delay + 3), new KeyValue(p.opacityProperty(), 0.15 + rand.nextDouble() * 0.12)),
          new KeyFrame(Duration.seconds(delay + 3 + dur),
              new KeyValue(p.translateXProperty(), dx, Interpolator.EASE_BOTH),
              new KeyValue(p.translateYProperty(), dy, Interpolator.EASE_BOTH),
              new KeyValue(p.opacityProperty(), 0.15 + rand.nextDouble() * 0.12)),
          new KeyFrame(Duration.seconds(delay + 3 + dur + 3),
              new KeyValue(p.opacityProperty(), 0, Interpolator.EASE_BOTH)));
    }
    tl.setCycleCount(Timeline.INDEFINITE);
    tl.play();
  }

  private void initFloatingGradients() {
    Random rand = new Random();

    double[][] blobSpecs = {
        {260, 0.14, 214, 148, 120},
        {300, 0.14, 177, 141, 184},
        {240, 0.14, 109, 168, 158}
    };
    String[] classes = {"floating-blob-peach", "floating-blob-lavender", "floating-blob-teal"};

    Circle[] blobs = new Circle[3];

    for (int i = 0; i < 3; i++) {
      Circle blob = new Circle(blobSpecs[i][0]);
      blob.getStyleClass().addAll("floating-blob", classes[i]);
      blob.setCenterX(200 + rand.nextDouble() * 300);
      blob.setCenterY(150 + rand.nextDouble() * 200);
      blob.setOpacity(0);
      floatingGradients.getChildren().add(blob);
      blobs[i] = blob;
    }

    Timeline tl = new Timeline();
    for (int i = 0; i < 3; i++) {
      Circle blob = blobs[i];
      double delay = rand.nextDouble() * 5;
      double startX = blob.getCenterX();
      double startY = blob.getCenterY();
      double dx1 = (rand.nextDouble() - 0.5) * 120;
      double dy1 = (rand.nextDouble() - 0.5) * 80;
      double dx2 = (rand.nextDouble() - 0.5) * 120;
      double dy2 = (rand.nextDouble() - 0.5) * 80;
      double dx3 = (rand.nextDouble() - 0.5) * 120;
      double dy3 = (rand.nextDouble() - 0.5) * 80;

      tl.getKeyFrames().addAll(
          new KeyFrame(Duration.seconds(delay), new KeyValue(blob.opacityProperty(), 0)),
          new KeyFrame(Duration.seconds(delay + 3), new KeyValue(blob.opacityProperty(), 0.8 + rand.nextDouble() * 0.2)),
          new KeyFrame(Duration.seconds(delay + 10),
              new KeyValue(blob.centerXProperty(), startX + dx1, Interpolator.EASE_BOTH),
              new KeyValue(blob.centerYProperty(), startY + dy1, Interpolator.EASE_BOTH)),
          new KeyFrame(Duration.seconds(delay + 20),
              new KeyValue(blob.centerXProperty(), startX + dx1 + dx2, Interpolator.EASE_BOTH),
              new KeyValue(blob.centerYProperty(), startY + dy1 + dy2, Interpolator.EASE_BOTH)),
          new KeyFrame(Duration.seconds(delay + 30),
              new KeyValue(blob.centerXProperty(), startX + dx1 + dx2 + dx3, Interpolator.EASE_BOTH),
              new KeyValue(blob.centerYProperty(), startY + dy1 + dy2 + dy3, Interpolator.EASE_BOTH)),
          new KeyFrame(Duration.seconds(delay + 35),
              new KeyValue(blob.opacityProperty(), 0.6, Interpolator.EASE_BOTH)),
          new KeyFrame(Duration.seconds(delay + 40),
              new KeyValue(blob.centerXProperty(), startX, Interpolator.EASE_BOTH),
              new KeyValue(blob.centerYProperty(), startY, Interpolator.EASE_BOTH)),
          new KeyFrame(Duration.seconds(delay + 43),
              new KeyValue(blob.opacityProperty(), 0, Interpolator.EASE_BOTH)));
    }
    tl.setCycleCount(Timeline.INDEFINITE);
    tl.play();
  }

  @FXML
  public void handleCloseDraft() {
    editingCompositionId = null;
    formulaName.setText("");
    formulaStatus.setText("");
    autoSaveService.clear();
    clearPyramid();
    updateAll();
    closeDraftBtn.setVisible(false);
    closeDraftBtn.setManaged(false);
  }

  @FXML
  public void handleSave() {
    if (userSession.getUserId() == null) {
      formulaStatus.setText("LOG IN TO SAVE");
      formulaStatus.getStyleClass().add("status-badge-warn");
      return;
    }
    String name = formulaName.getText().trim();
    if (name.isEmpty()) {
      formulaStatus.setText("NAME REQUIRED");
      formulaStatus.getStyleClass().add("status-badge-warn");
      return;
    }
    List<Note> all = allNotes();
    if (all.isEmpty()) {
      formulaStatus.setText("NO NOTES");
      formulaStatus.getStyleClass().add("status-badge-warn");
      return;
    }
    User userRef = new User();
    userRef.setId(userSession.getUserId());
    Composition composition;
    if (editingCompositionId != null) {
      composition = new Composition();
      composition.setId(editingCompositionId);
    } else {
      composition = new Composition();
    }
    composition.setName(name);
    composition.setDescription("Created in Velmora Olfactory Lab");
    composition.setPublic(false);
    composition.setUser(userRef);
    for (Note note : all) {
      CompositionItem item = new CompositionItem();
      item.setNoteId(note.getId());
      item.setPercentage(notePercentages.getOrDefault(note.getId(), 100 / all.size()));
      composition.getItems().add(item);
    }
    autoSaveService.forceSave();
    javafx.concurrent.Task<Void> task = new javafx.concurrent.Task<>() {
      @Override protected Void call() {
        compositionService.saveComposition(composition, "Manual save");
        return null;
      }
    };
    formulaStatus.setText("SAVING...");
    task.setOnSucceeded(e -> {
      formulaStatus.setText("SAVED ✓");
      formulaStatus.getStyleClass().remove("status-badge-warn");
      editingCompositionId = null;
      autoSaveService.clear();
    });
    task.setOnFailed(e -> {
      formulaStatus.setText("ERROR: " + task.getException().getMessage());
      formulaStatus.getStyleClass().add("status-badge-warn");
    });
    new Thread(task).start();
  }

  @FXML
  public void handleExport() {
    List<Note> all = allNotes();
    if (all.isEmpty()) {
      formulaStatus.setText("NOTHING TO EXPORT");
      formulaStatus.getStyleClass().add("status-badge-warn");
      return;
    }

    FileChooser chooser = new FileChooser();
    chooser.setTitle("Export Formula Report");
    chooser.getExtensionFilters().add(new FileChooser.ExtensionFilter("PDF Report", "*.pdf"));
    String baseName = formulaName.getText().trim();
    if (baseName.isEmpty()) baseName = "formula";
    chooser.setInitialFileName(baseName.replaceAll("\\s+", "_") + ".pdf");

    File file = chooser.showSaveDialog(formulaName.getScene().getWindow());
    if (file == null) return;

    formulaStatus.setText("EXPORTING...");
    formulaStatus.getStyleClass().remove("status-badge-warn");

    String name = baseName;
    AnalysisResult exportResult = analysisService.analyze(currentTopNotes, currentHeartNotes, currentBaseNotes);
    javafx.concurrent.Task<Void> task = new javafx.concurrent.Task<>() {
      @Override protected Void call() throws Exception {
        pdfExportService.export(file, name, all, exportResult);
        return null;
      }
    };
    task.setOnSucceeded(e -> {
      formulaStatus.setText("EXPORTED ✓");
      formulaStatus.getStyleClass().remove("status-badge-warn");
    });
    task.setOnFailed(e -> {
      formulaStatus.setText("EXPORT FAILED");
      formulaStatus.getStyleClass().add("status-badge-warn");
      System.out.println("[EXPORT] Error: " + task.getException().getMessage());
    });
    new Thread(task).start();
  }
  @FXML
  public void handleVault() { viewManager.showVault(); }
  @FXML
  public void handleSettings() { viewManager.showSettings(); }
  @FXML
  public void handleAdmin() { viewManager.showAdmin(); }
  @FXML
  public void handleHistory() {
    viewManager.showHistory();
  }

  private static Color parseColor(String code) {
    if (code == null || code.isBlank()) return Color.GRAY;
    try { return Color.web(code); } catch (Exception e) { return Color.GRAY; }
  }

  private static class MaterialCardCell extends ListCell<Note> {
    @Override
    protected void updateItem(Note note, boolean empty) {
      super.updateItem(note, empty);
      if (empty || note == null) {
        setGraphic(null);
        setStyle("-fx-background-color: transparent; -fx-padding: 3 0;");
      } else {
        HBox root = new HBox(12);
        root.setAlignment(Pos.CENTER_LEFT);
        root.getStyleClass().add("material-mini-card");

        Circle dot = new Circle(6);
        dot.getStyleClass().add("mcard-color-dot");
        dot.setFill(parseColor(note.getColorCode()));

        VBox info = new VBox(3);
        VBox.setVgrow(info, Priority.ALWAYS);

        Label name = new Label(note.getName() != null ? note.getName() : "");
        name.getStyleClass().add("mcard-name");

        HBox tags = new HBox(8);
        tags.setAlignment(Pos.CENTER_LEFT);
        Label cat = new Label(note.getCategory() != null ? note.getCategory().toUpperCase() : "");
        cat.getStyleClass().add("mcard-tags");
        Label phase = new Label(note.getType() != null ? note.getType().name() : "");
        phase.getStyleClass().addAll("mcard-phase-tag",
            note.getType() == NoteType.TOP ? "mcard-tag-top"
            : note.getType() == NoteType.HEART ? "mcard-tag-heart"
            : "mcard-tag-base");
        tags.getChildren().addAll(cat, phase);

        String descText = note.getDescription();
        if (descText != null && descText.length() > 55) descText = descText.substring(0, 52) + "...";
        Label desc = new Label(descText != null ? descText : "");
        desc.getStyleClass().add("mcard-desc");

        HBox meta = new HBox(8);
        meta.setAlignment(Pos.CENTER_LEFT);
        Label origin = new Label(note.getOrigin() != null ? note.getOrigin() : "");
        origin.getStyleClass().add("mcard-origin");
        HBox dots = new HBox(3);
        dots.setAlignment(Pos.CENTER_LEFT);
        int intensity = note.getIntensity() != null ? note.getIntensity() : 0;
        for (int i = 0; i < 5; i++) {
          Label d = new Label();
          d.getStyleClass().add("mcard-intense-dot");
          d.setStyle(String.format("-fx-background-color: %s;", i < intensity / 2 ? "#D4A89A" : "#EAE6DF"));
          dots.getChildren().add(d);
        }
        meta.getChildren().addAll(origin, dots);

        info.getChildren().addAll(name, tags, desc, meta);
        root.getChildren().addAll(dot, info);
        setGraphic(root);
        setStyle("-fx-background-color: transparent; -fx-padding: 3 20 3 4;");
      }
    }
  }
}
