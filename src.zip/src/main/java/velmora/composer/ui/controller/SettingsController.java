package velmora.composer.ui.controller;

import java.time.format.DateTimeFormatter;
import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.ListCell;
import javafx.scene.control.ListView;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;
import velmora.composer.model.Composition;
import velmora.composer.model.User;
import velmora.composer.repository.CompositionRepository;
import velmora.composer.service.UserService;
import velmora.composer.ui.UserSession;
import velmora.composer.ui.ViewManager;

@Component
@RequiredArgsConstructor
public class SettingsController {

  private final UserService userService;
  private final CompositionRepository compositionRepository;
  private final ViewManager viewManager;
  private final UserSession userSession;

  @FXML private Label profileInitials;
  @FXML private Label profileName;
  @FXML private Label profileEmail;
  @FXML private Label compCount;
  @FXML private TextField nicknameField;
  @FXML private TextField emailField;
  @FXML private PasswordField currentPasswordField;
  @FXML private PasswordField newPasswordField;
  @FXML private Label saveFeedback;
  @FXML private ListView<Composition> compositionsList;

  private User currentUser;

  @FXML
  public void initialize() {
    saveFeedback.setManaged(false);
    saveFeedback.setVisible(false);
    if (userSession.getUserId() == null) {
      profileName.setText("Not logged in");
      profileEmail.setText("Log in to manage your profile");
      return;
    }
    loadUser();
    loadCompositions();
  }

  private void loadUser() {
    currentUser = userService.findById(userSession.getUserId());
    String initials = userSession.getInitials() != null ? userSession.getInitials() : "?";
    profileInitials.setText(initials);
    profileName.setText(currentUser.getNickname());
    profileEmail.setText(currentUser.getEmail());
    nicknameField.setText(currentUser.getNickname());
    emailField.setText(currentUser.getEmail());
  }

  private void loadCompositions() {
    var items = compositionRepository.findByUserId(userSession.getUserId());
    compCount.setText(String.valueOf(items.size()));
    compositionsList.setItems(FXCollections.observableArrayList(items));
    compositionsList.setCellFactory(lv -> new ListCell<>() {
      @Override
      protected void updateItem(Composition c, boolean empty) {
        super.updateItem(c, empty);
        if (empty || c == null) {
          setText(null);
          setGraphic(null);
        } else {
          HBox box = new HBox(12);
          box.setStyle("-fx-padding: 6 0;");

          Circle dot = new Circle(3);
          dot.setFill(Color.web("#78A0A0"));

          Label name = new Label(c.getName());
          name.setStyle("-fx-font-size: 19; -fx-font-weight: 500;");
          HBox.setHgrow(name, Priority.ALWAYS);

          Label date = new Label(
              c.getCreatedAt() != null
                  ? c.getCreatedAt().format(DateTimeFormatter.ofPattern("dd MMM yyyy"))
                  : ""
          );
          date.setStyle("-fx-font-size: 17; -fx-text-fill: #B0ADA8;");

          box.getChildren().addAll(dot, name, date);
          setGraphic(box);
        }
      }
    });
  }

  @FXML
  public void handleSave() {
    if (userSession.getUserId() == null) {
      viewManager.showAuth();
      return;
    }
    hideFeedback();
    String newNickname = nicknameField.getText().trim();
    String newEmail = emailField.getText().trim();
    String oldPass = currentPasswordField.getText();
    String newPass = newPasswordField.getText();

    if (!oldPass.isEmpty() && newPass.isEmpty()) {
      showFeedback("Fill in both current and new password to change");
      return;
    }
    if (oldPass.isEmpty() && !newPass.isEmpty()) {
      showFeedback("Fill in both current and new password to change");
      return;
    }
    if (!newPass.isEmpty() && newPass.length() < 6) {
      showFeedback("Password must be at least 6 characters");
      return;
    }

    javafx.concurrent.Task<Void> task = new javafx.concurrent.Task<>() {
      @Override
      protected Void call() {
        if (!newNickname.equals(currentUser.getNickname())) {
          currentUser = userService.updateNickname(currentUser.getId(), newNickname);
        }
        if (!newEmail.equals(currentUser.getEmail())) {
          currentUser = userService.updateEmail(currentUser.getId(), newEmail);
        }
        if (!oldPass.isEmpty()) {
          currentUser = userService.updatePassword(currentUser.getId(), oldPass, newPass);
        }
        return null;
      }
    };
    task.setOnSucceeded(e -> {
      profileName.setText(currentUser.getNickname());
      profileEmail.setText(currentUser.getEmail());
      userSession.setNickname(currentUser.getNickname());
      userSession.setEmail(currentUser.getEmail());
      String nick = currentUser.getNickname();
      userSession.setInitials(nick != null && !nick.isEmpty()
          ? nick.substring(0, 1).toUpperCase() : "?");
      profileInitials.setText(userSession.getInitials());
      currentPasswordField.clear();
      newPasswordField.clear();
      showFeedback("Settings saved successfully");
    });
    task.setOnFailed(e -> showFeedback(task.getException().getMessage()));
    new Thread(task).start();
  }

  private void showFeedback(String message) {
    saveFeedback.setText(message);
    saveFeedback.setManaged(true);
    saveFeedback.setVisible(true);
  }

  private void hideFeedback() {
    saveFeedback.setManaged(false);
    saveFeedback.setVisible(false);
  }

  @FXML
  public void handleBack() {
    viewManager.showMain();
  }

  @FXML
  public void handleLogout() {
    userSession.clear();
    viewManager.showAuth();
  }
}
